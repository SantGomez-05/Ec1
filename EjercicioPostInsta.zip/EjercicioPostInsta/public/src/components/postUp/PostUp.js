class MyPostUp extends HTMLElement {

    constructor() {
        super();
        this.attachShadow({mode:'open'})
    }

    connectedCallback() {
        this.render();
    }

    render() {
        this.shadowRoot.innerHTML = `
        <link rel="stylesheet" href="./src/components/postUp/style.css">
        <section id="template">
        <img id="photo-insta" src="./assets/photo-insta.jpg">
        <img id="like" src="./assets/like.png">
        <img id="comment" src="./assets/comment.png">
        <img id="message" src="./assets/message.png">
        <img id="profile" src="./assets/profile.png">
        <img id="puntos-ubicacion-imagen" src="./assets/puntos-ubicacion-imagen.jpeg">
        <img id="puntos-opciones" src="./assets/puntos-opciones.jpeg">
        <img id="save" src="./assets/save.jpeg">
        <h1 id="personalUser">Santgome5</h1>
        <h1 id="location">Miami</h1>
        <h1 id="PeopleLikes">10.000</h1>
        <h1 id="publicComments">Buen debut!   #futbolamericano #thebestplayer #NFL</h1>
        </section>
        `
    }
}
//user: SantGomez5
//description: #Cityforever
//likes: 122
//comments: thats right

//<img id="city-post" src="./assets/city-post.webp"></img>

customElements.define("my-postup", MyPostUp)
export default MyPostUp
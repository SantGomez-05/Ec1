/*
class MyPostUp extends HTMLElement {

    constructor() {
        super();
        this.attachShadow({mode:'open'})
    }

    connectedCallback() {
        this.render();
    }

    render() {
        this.shadowRoot.innerHTML = `
        <link rel="stylesheet" href="./src/components/postUp/style.css">
        <section id="template"></section>
        <img id="photo-insta" src="./assets/photo-insta.jpg">
        <img id="like" src="./assets/like.png">
        <img id="comment" src="./assets/comment.png">
        <img id="message" src="./assets/message.png">
        <img id="profile" src="./assets/profile.png">
        <img id="puntos-ubicacion-imagen" src="./assets/puntos-ubicacion-imagen.jpeg">
        <h1></h1>
        
        `
    }
}
*/